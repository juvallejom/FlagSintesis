function f=simJP(L1,L2,L3,L4, t3)

    format SHORTG
    a=L2;                        %Manivela
    b=L3;                        %Acopador
    c=L4;                        %Salida
    d=L1;                        %Bancada
    e=0;                        %Extension Acoplador
    alpha=0;                     %Angulo extension acoplador 
    ar=alpha*pi/180;            
    theta=283.069:1:360+283.069; %Ángulo de entrada manivela 
    gamma= -45.53;                 %Ángulo de inclinación bancado
    gr = gamma*pi/180;
    T=theta*pi/180;              
    f=sqrt(a*a+d*d-2*a*d*cos(T)); 


    for i=1:length(theta) 

    %G(i)=atan((a*sin(T(i)))/(d-a*cos(T(i))));
    %Bita(i)=acos((f(i).*f(1,i)+b*b-c*c)/(2*b*f(i)))-G(i);
    Bita(i)=t3(i);


    X(i)=a*cos(T(i))+e*cos(ar+Bita(i));
    Y(i)=a*sin(T(i))+e*sin(ar+Bita(i));


    %% Section 3 :Animacion 
    hold on;
    title('FourBar Coupler Curve Plotting')
    xlim([-50,100])
    ylim([-50,50])
    grid on
    plot(X,Y,'b','Linewidth',1)

    %Trace= viscircles([X(i) Y(i)],2,'Color','k');

    Cx=[0 a*cos(T(i)) b*cos(Bita(i))+a*cos(T(i)) d*cos(gr) a*cos(T(i))+e*cos(Bita(i)+ar)];
    Cy=[0 a*sin(T(i)) b*sin(Bita(i))+a*sin(T(i)) d*sin(gr) a*sin(T(i))+e*sin(Bita(i)+ar)];

    crank=line([0 Cx(2)],[0 Cy(2)],'color','r','linewidth',5);%link 1
    coupler=line([Cx(2) Cx(3)],[Cy(2) Cy(3)],'color','g','linewidth',5);%link 2
    output=line([Cx(3) Cx(4)],[Cy(3) Cy(4)],'color','y','linewidth',5);%link 3
    fix=line([Cx(1) Cx(4)],[Cy(1) Cy(4)],'color','k','linewidth',5);%link
    eline=line([Cx(2) Cx(5)],[Cy(2) Cy(5)],'color','c','linewidth',3);
    eoline=line([Cx(5) Cx(3)],[Cy(5) Cy(3)],'color','c','linewidth',3);%link e joint

    %Animacion 
    pause(0.005)
    delete(crank)
    delete(coupler)
    delete(output)
    delete(fix)
    delete(eline)
    delete(eoline)
    %delete(Trace)
    end
    %% Posicion inciial
    crank=line([0 Cx(2)],[0 Cy(2)],'color','r','linewidth',5);%link 1
    coupler=line([Cx(2) Cx(3)],[Cy(2) Cy(3)],'color','g','linewidth',5);%link 2
    output=line([Cx(3) Cx(4)],[Cy(3) Cy(4)],'color','y','linewidth',5);%link 3
    fix=line([Cx(1) Cx(4)],[Cy(1) Cy(4)],'color','k','linewidth',5);%link4
    eline=line([Cx(2) Cx(5)],[Cy(2) Cy(5)],'color','c','linewidth',3);
    eoline=line([Cx(5) Cx(3)],[Cy(5) Cy(3)],'color','c','linewidth',3);%link e joint
    
    f=L1+L2;
end 

