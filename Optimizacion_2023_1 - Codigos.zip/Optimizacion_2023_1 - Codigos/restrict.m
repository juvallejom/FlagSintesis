function [c,ceq]=restrict(x)
    e=1;
    r2_deltax=x(1);
    r1_r2=x(2);
    r3_r2=x(3);
    c=[ 1-r1_r2+e;
       -r2_deltax;
       -r3_r2;
       -r2_deltax];
    ceq=[];
end