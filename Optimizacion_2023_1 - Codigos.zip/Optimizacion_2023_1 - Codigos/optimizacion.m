
clc
%Script de optimizacion
deltax=80;
x0=[0.838 2.925 3.95];
fun=@cuatrobarras;
cons=@restrict;
lp=[0 0 0];
up=[100 100 100];

%options = optimoptions(SolverName,Name,Value)
options = optimoptions('fmincon','Display','iter','OptimalityTolerance',1e-10,'StepTolerance',1e-10,'ConstraintTolerance',1e-15,'Algorithm','sqp');
[x,fval,output,lambda]=fmincon(fun,x0,[],[],[],[],lp,up,cons,options)

L2=x(1)*deltax
L1=x(2)*L2
L3=x(3)*L2

fun2=simulacion_4barras(L1,L2,L3);

