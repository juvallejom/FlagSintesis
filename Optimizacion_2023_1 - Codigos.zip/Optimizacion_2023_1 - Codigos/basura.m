
theta0=0; %deg2rad(-45.35);
deltabeta=2*pi;
deltax=80;

r2=19.16;
r1=50.91;
r3=49;
r4=28.38;

theta30=-180;
theta40=60;



t=(theta0:0.01:theta0+deltabeta)';
tp = linspace(0, 1,629)';
theta3arr=zeros(length(t),1);
theta4arr=zeros(length(t),1);


for  i=1:length(t)
    theta1=deg2rad(0);
    theta2=deg2rad(t(i));
    if i==1
        theta3=deg2rad(theta30);
        theta4=deg2rad(theta40);
    else
        theta3=theta3arr(i-1);
        theta4=theta4arr(i-1);
    end
    error1=1;
    error2=1;
    vecerror=[1,1];


    while abs(vecerror)>1e-11
        theta3ant=theta3;
        theta4ant=theta4;

        J=[r3*cos(theta3), -r4*cos(theta4);
            -r3*sin(theta3), r4*sin(theta4)];

        F=[r2*sin(theta2)+r3*sin(theta3)-r1*sin(theta1)-r4*sin(theta4); ...
           r2*cos(theta2)+r3*cos(theta3)-r1*cos(theta1)-r4*cos(theta4)];

        delta=J\(-F);

        theta3=theta3+delta(1);
        theta4=theta4+delta(2);

        error1=theta3-theta3ant;
        error2=theta4-theta4ant;

        vecerror=[error1 error2];
    end
    theta3arr(i)=theta3;
    theta4arr(i)=theta4;
end
coordp=[cos(deg2rad(t))*r2+cos(theta3arr)*r3*2,sin(deg2rad(t))*r2+sin(theta3arr)*r3*2];
coordp_jp=[cos(deg2rad(t))*r2+2*cos(theta3arr)*r3,+sin(deg2rad(t))*r2+2*sin(theta3arr)*r3];

figure(1),clf
plot(coordp(:,1), coordp(:,2))


errorY=(max(coordp(:,2))-min(coordp(:,2)))/deltax

