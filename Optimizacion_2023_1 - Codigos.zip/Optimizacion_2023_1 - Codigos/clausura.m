%Analisis por ecuaciones de clausura


    r2=19.16;
    r1=50.91;
    r3=49;
    r4=28.38;
    circuito =2;
    t1 = linspace(0, 1,361)';

    ang1=deg2rad(-45.53);

    deltab=deg2rad(360);
    deltax=80;
 
    
    %%CALCULO DE ANGULOS 3 Y 4 A PARTIR DE LAS ECUACIONES DE CLAUSURA 
    ts=1; % [s] tiempo de simulación
    ns=360; % Número de incrementos del tiempo
    dt=ts/ns; % incremento en timepo [s];
    ang2_0=283.069*pi/180; % Angulo inicial de la biela 
    t=linspace(ang2_0,2*pi+ang2_0, 361); %% arange = arreglo que esta dentro de un rango, es como el análogo al linspace en Matlab. Este vector es el del tiempo de simulación
    vang2=zeros(length(t),1); %vector ; contiene los valores del angulo 2 de 0 a 360; incializado en 0 por el momento ; RADIANES
    vang3=zeros(length(t),1); %ector ; contiene los valores del angulo 3 respecto al angulo 2; incializado en 0 por el momento ; RADIANES 
    vang4=zeros(length(t),1); %ector ; contiene los valores del angulo 4 respecto al angulo 2; incializado en 0 por el momento  ; RADIANES
    vdang2=zeros(length(t),1); %vector ; contiene los valores del angulo 2 de 0 a 360; incializado en 0 por el momento ; GRADOS 
    vdang3=zeros(length(t),1); %ector ; contiene los valores del angulo 3 respecto al angulo 2; incializado en 0 por el momento ; GRADOS
    vdang4=zeros(length(t),1); %ector ; contiene los valores del angulo 4 respecto al angulo 2; incializado en 0 por el momento  ; GRADOS 
    
    %w=2*np.pi; % velocidad de rotacion en la simulacion (2pi rad /s)
    
    for n=1:length(t)
      vang2(n)=t(n);
      vdang2(n)=vang2(n)*180/pi;
      %Calculo Angulo 4 
      k1=(power(r1,2)+power(r2,2)+power(r4,2)-power(r3,2))/(2*r2*r4); 
      k2=r1/r4;
      k3=r1/r2;
      A=k1-k2*(sin(ang1)*sin(vang2(n))+cos(ang1)*cos(vang2(n)))-...
          k3*cos(ang1)+cos(vang2(n));
      B=2*(k3*sin(ang1)-sin(vang2(n)));
      C=k1-k2*(sin(ang1)*sin(vang2(n))+cos(ang1)*cos(vang2(n)))+...
          k3*cos(ang1)-cos(vang2(n));
      sol4a=(-B+sqrt(power(B,2)-4*A*C))/(2*A);
      sol4b=(-B-sqrt(power(B,2)-4*A*C))/(2*A);
      if circuito==1
        vang4(n)=2*atan(sol4a);
      end
      if circuito==2
        vang4(n)=2*atan(sol4b);
      end
      vdang4(n)=vang4(n)*180/pi;
    
    
      %%Calculo Angulo 3 
      k4=(power(r4,2)-power(r1,2)-power(r2,2)-power(r3,2))/(2*r2*r3);
      k5=r1/r3;
      k6=r1/r2;
      D=k4+k5*(sin(ang1)*sin(vang2(n))+cos(ang1)*cos(vang2(n)))...
          -k6*cos(ang1)+cos(vang2(n));
      E=2*(k6*sin(ang1)-sin(vang2(n)));
      F=k4+k5*(sin(ang1)*sin(vang2(n))+cos(ang1)*cos(vang2(n)))...
          +k6*cos(ang1)-cos(vang2(n));
      sol3a=(-E+sqrt(power(E,2)-4*D*F))/(2*D);
      sol3b=(-E-sqrt(power(E,2)-4*D*F))/(2*D);
      if circuito==1
        vang3(n)=2*atan(sol3a);
      end
      if circuito==2
        vang3(n)=2*atan(sol3b);
      end
      vdang3(n)=vang3(n)*180/pi; 
    end
coordp=[cos(deg2rad(t))*r2+cos(vang3)*r3*2,sin(deg2rad(t))*r2+sin(vang3)*r3*2];

plot(coordp(:,1), coordp(:,2))

errorY=(max(coordp(:,2))-min(coordp(:,2)))/deltax 
figure(1), clf
K = simJP(r1, r2, r3, r4, vang3);


figure(2), clf
grid on
subplot(3,1,1)
plot(t1, vdang2)
title('Ángulo2 vs Tiempo')
hold on

subplot(3,1,2)
plot(t1, vdang3)
title('Ángulo3 vs Tiempo')

subplot(3,1,3)
plot(t1, vdang4)
title('Ángulo4 vs Tiempo')
hold off






  